<?php

namespace YoutubeBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    public function indexAction()
    {
        $client = new \Google_Client();
        $client->setApplicationName("Client_Youtube_Examples");
        $apiKey = "AIzaSyBJiODpeDliOEhnDljXdxYOJ3820gpFfdo"; // Change this line.
        // Warn if the API key isn't changed.
        if (strpos($apiKey, "<") !== false) {
            echo missingApiKeyWarning();
            exit;
        }
        $client->setDeveloperKey($apiKey);

        $service = new \Google_Service_YouTube($client);

        // Call the search.list method to retrieve results matching the specified
        // query term.
        $searchResponse = $service->search->listSearch('id,snippet', array(
            'q' => 'geekdos',
            'maxResults' => 10,
            'type' => 'video'
        ));
        $videos = array();
        $channels = array();
        $playlists = array();
        // Add each result to the appropriate list, and then display the lists    of
        // matching videos, channels, and playlists.
        foreach ($searchResponse['items'] as $searchResult) {
            switch ($searchResult['id']['kind']) {
                case 'youtube#video':
                    $videos[]= array(
                        "title" => $searchResult['snippet']['title'],
                        "video_id" => $searchResult['id']['videoId'],
                        "video_img" => $searchResult['snippet']['thumbnails']['high']['url'],
                        "video_description" => $searchResult['snippet']['description'],
                        "video_dure" => $searchResult['snippet']['title'],
                    );
                    break;
                case 'youtube#channel':
                    $channels[]= array("title" => $searchResult['snippet']['title'], "channel_id" => $searchResult['id']['channelId']);
                    break;
                case 'youtube#playlist':
                    $playlists[]= array("title" => $searchResult['snippet']['title'], "playlist_id" => $searchResult['id']['playlistId']);
                    break;
            }
        }

        return $this->render('YoutubeBundle:Default:index.html.twig',
            array(
                'youtube_videos' => $videos,
                'youtube_channels' => $channels,
                'youtube_playlists' => $playlists
            )
        );
    }

    public function viewAction($video_id){

        return $this->render('YoutubeBundle:Default:view.html.twig',
            array(
                'video_id' => $video_id,
            )
        );
    }

    public function uploadAction(){
        $client = new \Google_Client();
        $appName = "Client_Youtube_Examples";
        $clientID = "812035859614-4be6vtvcm74vgahfe8ba40smb7raespf.apps.googleusercontent.com";
        $clientSecret = "maofE7ZOXHJp4tQyLY3tRh5o";
        $apiKey = "AIzaSyBJiODpeDliOEhnDljXdxYOJ3820gpFfdo";
        $redirectUri = "http://geekdos.com/app_dev.php/youtube/upload";
        $scoop = 'https://www.googleapis.com/auth/youtube';

        $client->setApplicationName($appName);
        $client->setClientId($clientID);
        // Warn if the API key isn't changed.
        if (strpos($apiKey, "<") !== false) {
            echo missingApiKeyWarning();
            exit;
        }
        $client->setDeveloperKey($apiKey);
        $client->setClientSecret($clientSecret);
        $client->setRedirectUri($redirectUri);
        $client->setScopes($scoop);

        $youtube = new \Google_Service_YouTube($client);

        $autUrl = $client->createAuthUrl();

        $token = null;

        if(isset($_GET['code'])){
            $client->authenticate($_GET['code']);
            $token = $client->getAccessToken();

        }

        if($token != null){
            $client->setAccessToken($token);

            $videoSnippet = new  \Google_Service_YouTube_VideoSnippet();
            $videoSnippet->setTitle('Videt de test');
            $videoSnippet->setDescription('Text de description');
            $videoSnippet->setTags('tag1', 'tag2', 'tag3');
            $videoSnippet->setCategoryId(17);

            $status = new \Google_Service_YouTube_VideoStatus();
            $status->setPrivacyStatus('private');

            $video = new  \Google_Service_YouTube_Video();

            $video->setSnippet($videoSnippet);
            $video->setStatus($status);

            $client->setDefer(true);
            $request = $youtube->videos->insert('status, snippet', $video);
            $file = 'C:\wamp\www\geekdos\web\videos\video.MKV';
            $media = new  \Google_Http_MediaFileUpload(
                $client,
                $request,
                'video/*',
                file_get_contents($file)
            );

            $response = $client->execute($request);

        }

        return $this->render('YoutubeBundle:Default:upload.html.twig',
            array(
                'urlAut' =>$autUrl,
                'token' =>$token,
            )
        );
    }

}
