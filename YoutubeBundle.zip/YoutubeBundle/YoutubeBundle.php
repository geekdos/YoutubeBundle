<?php

namespace YoutubeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class YoutubeBundle extends Bundle
{
}
